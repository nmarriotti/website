####################################

InstallRoot_PKCS7_v3.16.1A

####################################


Verification:


To verify this InstallRoot PKCS#7 package please perform the following steps:


1)  Verify Thumbprint on the first DoD_PKE_CA_chain.pem certificate using the following command:
openssl x509 -in DoD_PKE_CA_chain.pem -subject -issuer -fingerprint -noout


Verify the following output:
subject=/C=US/O=U.S. Government/OU=DoD/OU=PKI/CN=DoD Root CA 2
issuer= /C=US/O=U.S. Government/OU=DoD/OU=PKI/CN=DoD Root CA 2
SHA1 Fingerprint=8C:94:1B:34:EA:1E:A6:ED:9A:E2:BC:54:CF:68:72:52:B4:C9:B5:61

Confirm output and verify the DoD Root CA 2 SHA1 Fingerprint by contacting the DoD PKI Help Desk at (800) 490-1643
 or DSN 339-5600.


2) Open DoD_PKE_CA_chain.pem in a text editor and confirm only two CERTIFICATE objects are present.


3) Verify the S/MIME signature on InstallRoot_PKCS7_v3.16.1A.sha1 using the following command:
openssl smime -verify -in InstallRoot_PKCS7_v3.16.1A.sha1 -CAfile DoD_PKE_CA_chain.pem | dos2unix | sha1sum -c

Verify the following output:
Verification successful
InstallRoot_PKCS7_v3.16.1A.der.p7b: OK
InstallRoot_PKCS7_v3.16.1A.pem.p7b: OK
InstallRoot_PKCS7_v3.16.1A.pem-signed.p7b: OK


4) Verify the S/MIME signature on InstallRoot_PKCS7_v3.16.1A.pem-signed.p7b using the following command:
openssl smime -verify -in InstallRoot_PKCS7_v3.16.1A.pem-signed.p7b -CAfile DoD_PKE_CA_chain.pem


Confirm "Verification successful" is displayed following the PKCS7 printout.


####################################

Usage:


Openssl - To export CA certificates to a concatenated PEM file for use as an openssl CAfile (named e.g. DoD_CAs.pem), use the following command:
openssl pkcs7 -in InstallRoot_PKCS7_v3.16.1A.pem-signed.p7b -print_certs -out DoD_CAs.pem


Firefox 3.6 - To import certificates into the browser trust store, open the browser and select Edit > Preferences > Advanced > Encryption > View Certificates > Import... > All Files > InstallRoot_PKCS7_v3.16.1A.der.p7b


Firefox 6.0 - To import certificates into the browser trust store:

1. Open the browser and select Firefox > Options > Advanced.  

2. Select the Encryption tab and click the View Certificates button.  

3. Select the Authorities tab and click Import...

4. In the file types picklist, select All Files

5. Browse to and select InstallRoot_PKCS7_v3.16.1A.der.p7b
.  Click Open.6. Check all three boxes ("Trust this CA to identify web sites", "Trust this CA to identify email users", and "Trust this CA to identify software developers") when prompted and click OK.

